package com.emedinaa.comovil2015.model.response;

/**
 * Created by emedinaa on 21/09/15.
 */
public class PokemonAddResponse
{
    private String createdAt;
    private String objectId;

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }
}
