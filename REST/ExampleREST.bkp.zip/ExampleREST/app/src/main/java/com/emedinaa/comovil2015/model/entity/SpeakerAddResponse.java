package com.emedinaa.comovil2015.model.entity;

/**
 * Created by emedinaa on 21/09/15.
 */
public class SpeakerAddResponse
{
    private String createdAt;
    private String objectId;

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }
}
