package com.emedinaa.monkey;

/**
 * Created by emedinaa on 12/09/15.
 */
public class Response<T> {
}
